<?php $this->load->view("admin/includes/header") ?>
<div class="row">

    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
            <?php echo form_open_multipart('') ?>

                <div class="form-group row">
                    <label for="" class="col-form-label col-md-4">Nama Karyawan</label>
                    <div class="col-md-8">
                        <input type="text" class="form-control" value="<?php echo $this->session->userdata('userlogin')['nama'] ?>" disabled>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="" class="col-form-label col-md-4">Tanggal</label>
                    <div class="col-md-8">
                        <input type="date" name="tanggal" class="form-control form-tanggal" value="<?php echo date('Y-m-d') ?>">
                    </div>
                </div>
               

                <?php echo form_close() ?>
            </div>
        </div>
    </div>


    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
            <?php echo form_open_multipart('') ?>

                <div class="form-group row">
                            <label for="" class="col-form-label col-md-4">Nama Kios</label>
                                <div class="col-md-10">
                                <select name="fk_kios" class="form-control" id="kios">
                                        <option value="-1">Choose</option>
                                        <?php foreach ($this->db->get('kios')->result() as $key => $value) : ?>
                                            <option value="<?php echo $value->id_kios ?>"><?php echo $value->nama_kios ?></option>
                                        <?php endforeach ?>
                                    </select>
                                    <?php echo form_error('fk_kios', '', '') ?>
                                </div>
                            </div>
                            <div class="form-group row">
                            <label for="" class="col-form-label col-md-4">Pupuk</label>
                                <div class="col-md-10">
                                <select name="fk_pupuk" class="form-control" id="pupuk">
                                        <option value="-1">Choose</option>
                                        <?php foreach ($this->db->get('pupuk')->result() as $key => $value) : ?>
                                            <option value="<?php echo $value->id_pupuk ?>"><?php echo $value->nama_pupuk ?></option>
                                        <?php endforeach ?>
                                    </select>
                                    <?php echo form_error('fk_pupuk', '', '') ?>
                                </div>
                            </div>
                            <div class="form-group row">
                            <label for="" class="col-form-label col-md-4">Jumlah</label>
                                <div class="col-md-10">
                                    <input type="number" name="jumlah" class="form-control" placeholder="jumlah" value=1 min=1>
                                    <?php echo form_error('jumlah', '', '') ?>
                                </div>
                            </div>

                            <div class="form-group row">
                            <label for="" class="col-form-label col-md-4">Nama Supir</label>
                                <div class="col-md-10">
                                    <input type="text" name="supir" class="form-control" placeholder="nama supir" value="">
                                    <?php echo form_error('supir', '', '') ?>
                                </div>
                            </div>
                            <label for="" class="col-form-label col-md-4">Nomor Polisi</label>
                                <div class="col-md-10">
                                    <input type="text" name="nopol" class="form-control" placeholder="nomor polisi" value="">
                                    <?php echo form_error('nopol', '', '') ?>
                                </div>
                            </div>

                            <div class="row">
                   
                             </div>

                             <div class="row">
                    <div class="offset-md-4 col-md-8">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>



                <?php echo form_close() ?>
            </div>
        </div>
    </div>
</div>
<?php $this->load->view("admin/includes/footer") ?>
<script>
    var cname_url = "<?php echo base_url('Distribusi') ?>";
    var index = 0;

    $(document).ready(function() {
        $('#form-produk').submit(function(e) {
            e.preventDefault();

            let elementForm = $(this);

            let fk_pupuk = elementForm.find('[name="fk_pupuk"]').val();
            let stok = elementForm.find('[name="fk_produk"] :selected').data('stok');
            let jumlah = elementForm.find('[name="jumlah"]').val();

            let is_already_exist = false;
            $('.container-produk').find('.fk_produk').each(function(i, obj) {
                if ($(obj).val() == fk_produk) {
                    is_already_exist = true;
                    let jum = $(obj).parents(".produk").find('.jumlah').val();
                    let sum = parseInt(jum) + parseInt(jumlah);
                    $(obj).parents(".produk").find('.jumlah').val(sum);
                }
            });
            if (!is_already_exist) {

                let old_html = $('#sample-produk').html();
                $('#sample-produk').find('[name="fk_produk"]').prop('name', "produk[" + index + "][fk_produk]");
                $('#sample-produk').find('[name="jumlah"]').prop('name', "produk[" + index + "][jumlah]");

                let html = $('#sample-produk').html();
                $('.container-produk').append(html);

                $('.container-produk').find('.produk').last().find('.fk_produk').val(fk_produk);
                $('.container-produk').find('.produk').last().find('.jumlah').val(jumlah);
                $('.container-produk').find('.produk').last().find('.jumlah').attr('max',stok);

                $('#sample-produk').html(old_html);
                index++;
            }
        });

        $('#form-persediaan').submit(function(e) {
            e.preventDefault();


            let fk_kios = $(".form-kios").val();

            if (fk_kios == "") {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Please fill kios',
                })
                return;
            }

            let elementForm = $(this);
            let submitForm = elementForm.find('button[type="submit"]');

            let formData = new FormData(this);

            $.ajax({
                    url: cname_url + "/add_distribusi",
                    type: 'POST',
                    data: formData,
                    dataType: 'JSON',
                    cache: false,
                    contentType: false,
                    processData: false,
                    beforeSend: () => {
                        submitForm.addClass('disabled');
                    }
                })
                .done((data) => {
                    $('.container-produk').html("");
                    $('.form-kios').val("");

                    Swal.fire({
                        icon: data.type,
                        title: data.title,
                        text: data.text,
                    })

                    let alert_html = "";
                    alert_html += '<a href="' + data.detail_url + '">';
                    alert_html += '<div class="alert alert-primary">';
                    alert_html += 'Berhasil melakukan tambah surat jalan';
                    alert_html += '</div>';
                    alert_html += '</a>';

                    $('#alert-container').append(alert_html);

                    submitForm.removeClass('disabled');
                });

        });

        $('.form-kios').change(function() {
            let fk_kios = $(this).val();
            $('#fk_kios').val(fk_kios);
        })
    });

   
</script>